# EvoTree (Python)

Visualizador de **árvore N-ária** das cadeias de evolução da **PokéAPI**, com
algoritmos clássicos de estrutura de dados (percursos, busca, inserção,
remoção) e métricas em tempo real (altura da árvore, grau do nó).

## Como rodar

```bash
python app.py
```

### Requisitos

- Python **3.9+** com **Tkinter** (já vem por padrão na maioria dos sistemas).
  - Linux: `sudo apt install python3-tk`
  - macOS / Windows: já incluso no instalador oficial do python.org
- **Opcional** (mostra os sprites dos Pokémons nos nós):
  ```bash
  pip install pillow
  ```

## Recursos

- Carrega a cadeia evolutiva de qualquer espécie da PokéAPI (`eevee`, `bulbasaur`, …).
- Renderiza a árvore num canvas com arestas suaves e seleção por clique.
- **Percursos**: pré-ordem, em-ordem, pós-ordem e BFS (em largura).
- **Busca por nome (BFS)** destacando o caminho da raiz até o nó.
- **Manipulação local**: inserir filho e remover subárvore — os ponteiros
  (`parent` / `children`) são atualizados de forma a manter a hierarquia íntegra.
- Painel de **métricas em tempo real**: altura total, grau do nó, tamanho da subárvore.

## Arquitetura

| Arquivo       | Responsabilidade                                            |
|---------------|-------------------------------------------------------------|
| `tree.py`     | `TreeNode` + algoritmos (percursos, busca, métricas, edição) |
| `pokeapi.py`  | Cliente HTTP da PokéAPI → converte JSON em `TreeNode`        |
| `app.py`      | Interface Tkinter, canvas e ligação com a lógica            |
