"""EvoTree (Python/Tkinter) — Visualizador de árvore de evolução PokéAPI.

Recursos:
  • Carrega cadeia evolutiva da PokéAPI
  • Renderiza a árvore em um Canvas (com sprites)
  • Percursos: pré-ordem, em-ordem, pós-ordem, BFS
  • Busca por nome (BFS) destacando o caminho da raiz
  • Inserção e remoção de nós (manipulação local)
  • Métricas em tempo real: altura da árvore, grau do nó, total de nós

Como rodar:  python app.py
Requisitos:  Python 3.9+ com Tkinter (padrão na maioria das instalações).
             Opcional: pip install pillow  (para mostrar sprites)
"""
from __future__ import annotations
import io
import threading
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from typing import Dict, List, Optional, Tuple
import urllib.request

from tree import (
    TreeNode, find_path, search_by_name, insert_child, delete_node,
    tree_height, node_degree, count_nodes,
    pre_order, in_order, post_order, bfs,
)
from pokeapi import fetch_evolution_tree

try:
    from PIL import Image, ImageTk  # type: ignore
    HAS_PIL = True
except Exception:
    HAS_PIL = False


# ---------- Paleta (tema escuro, inspirado na versão web) ----------
BG        = "#0b1020"
PANEL     = "#141a2e"
BORDER    = "#1f2742"
TEXT      = "#e6e9f2"
MUTED     = "#8a93b2"
PRIMARY   = "#7c5cff"
ACCENT    = "#22d3ee"
SUCCESS   = "#34d399"
DANGER    = "#f87171"
HIGHLIGHT = "#fbbf24"

NODE_W, NODE_H = 130, 60
H_GAP, V_GAP   = 30, 90


# =====================================================================
# Layout: posiciona nós num plano (x,y) sem sobreposição
# =====================================================================
def layout_tree(root: TreeNode) -> Tuple[Dict[str, Tuple[float, float]], float, float]:
    positions: Dict[str, Tuple[float, float]] = {}

    def subtree_width(n: TreeNode) -> float:
        if not n.children:
            return NODE_W
        return sum(subtree_width(c) for c in n.children) + H_GAP * (len(n.children) - 1)

    def place(n: TreeNode, x: float, y: float) -> None:
        w = subtree_width(n)
        positions[n.id] = (x + w / 2, y)
        if not n.children:
            return
        cx = x
        for c in n.children:
            cw = subtree_width(c)
            place(c, cx, y + V_GAP)
            cx += cw + H_GAP

    total_w = subtree_width(root)
    place(root, 0, 0)
    total_h = (tree_height(root) + 1) * V_GAP
    return positions, total_w + NODE_W, total_h + NODE_H


# =====================================================================
# App
# =====================================================================
class EvoTreeApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("EvoTree — Visualizador de Árvores · PokéAPI")
        self.geometry("1280x780")
        self.configure(bg=BG)

        self.root_node: Optional[TreeNode] = None
        self.selected_id: Optional[str] = None
        self.path_ids: set[str] = set()
        self.found_id: Optional[str] = None
        self.traversal_label: str = ""
        self.traversal_names: List[str] = []
        self._image_cache: Dict[str, "ImageTk.PhotoImage"] = {}
        self._node_items: Dict[int, str] = {}  # canvas item id -> node id

        self._setup_style()
        self._build_ui()
        self.after(100, lambda: self.load_chain("eevee"))

    # ---------- estilos ttk ----------
    def _setup_style(self) -> None:
        s = ttk.Style(self)
        try:
            s.theme_use("clam")
        except tk.TclError:
            pass
        s.configure(".", background=BG, foreground=TEXT, fieldbackground=PANEL)
        s.configure("TFrame", background=BG)
        s.configure("Panel.TFrame", background=PANEL)
        s.configure("TLabel", background=BG, foreground=TEXT)
        s.configure("Panel.TLabel", background=PANEL, foreground=TEXT)
        s.configure("Muted.TLabel", background=PANEL, foreground=MUTED)
        s.configure("Title.TLabel", background=BG, foreground=TEXT,
                    font=("Helvetica", 16, "bold"))
        s.configure("H2.TLabel", background=PANEL, foreground=TEXT,
                    font=("Helvetica", 11, "bold"))
        s.configure("TButton", background=PRIMARY, foreground="white",
                    borderwidth=0, focusthickness=0, padding=6)
        s.map("TButton",
              background=[("active", "#6a4cf0"), ("disabled", "#3a3f5a")])
        s.configure("Ghost.TButton", background=PANEL, foreground=TEXT,
                    borderwidth=1, relief="solid", padding=6)
        s.map("Ghost.TButton",
              background=[("active", BORDER)],
              bordercolor=[("!disabled", BORDER)])
        s.configure("Danger.TButton", background=DANGER, foreground="white",
                    borderwidth=0, padding=6)
        s.map("Danger.TButton", background=[("active", "#e25c5c")])
        s.configure("TEntry", fieldbackground=PANEL, foreground=TEXT,
                    insertcolor=TEXT, bordercolor=BORDER)

    # ---------- UI ----------
    def _build_ui(self) -> None:
        # cabeçalho
        header = ttk.Frame(self)
        header.pack(side="top", fill="x", padx=16, pady=(14, 8))
        ttk.Label(header, text="🌳  EvoTree", style="Title.TLabel").pack(side="left")
        ttk.Label(header, text="  Estruturas de Dados · Caminhamentos · Busca",
                  background=BG, foreground=MUTED).pack(side="left")

        body = ttk.Frame(self)
        body.pack(fill="both", expand=True, padx=16, pady=(0, 14))
        body.columnconfigure(1, weight=1)
        body.rowconfigure(0, weight=1)

        # painel esquerdo (controles)
        left = ttk.Frame(body, style="Panel.TFrame", padding=14)
        left.grid(row=0, column=0, sticky="ns", padx=(0, 12))
        self._build_controls(left)

        # canvas central
        center = ttk.Frame(body, style="Panel.TFrame", padding=2)
        center.grid(row=0, column=1, sticky="nsew")
        self._build_canvas(center)

        # painel direito (métricas)
        right = ttk.Frame(body, style="Panel.TFrame", padding=14, width=300)
        right.grid(row=0, column=2, sticky="ns", padx=(12, 0))
        right.grid_propagate(False)
        self._build_metrics(right)

        # barra de status
        self.status = tk.StringVar(value="Pronto.")
        status_bar = tk.Label(self, textvariable=self.status, bg=PANEL, fg=MUTED,
                              anchor="w", padx=12, pady=4)
        status_bar.pack(side="bottom", fill="x")

    def _build_controls(self, parent: ttk.Frame) -> None:
        ttk.Label(parent, text="API · PokéAPI", style="H2.TLabel").pack(anchor="w")
        ttk.Label(parent, text="Carregar cadeia evolutiva por nome:",
                  style="Muted.TLabel").pack(anchor="w", pady=(6, 4))

        row = ttk.Frame(parent, style="Panel.TFrame")
        row.pack(fill="x")
        self.species_var = tk.StringVar(value="eevee")
        ent = ttk.Entry(row, textvariable=self.species_var)
        ent.pack(side="left", fill="x", expand=True)
        ent.bind("<Return>", lambda e: self.load_chain(self.species_var.get()))
        ttk.Button(row, text="Carregar",
                   command=lambda: self.load_chain(self.species_var.get())
                   ).pack(side="left", padx=(6, 0))

        chips = ttk.Frame(parent, style="Panel.TFrame")
        chips.pack(fill="x", pady=(8, 14))
        for n in ("eevee", "bulbasaur", "charmander", "pichu", "tyrogue"):
            ttk.Button(chips, text=n, style="Ghost.TButton",
                       command=lambda x=n: (self.species_var.set(x), self.load_chain(x))
                       ).pack(side="left", padx=(0, 4), pady=2)

        ttk.Separator(parent).pack(fill="x", pady=8)
        ttk.Label(parent, text="Busca (BFS)", style="H2.TLabel").pack(anchor="w")
        srow = ttk.Frame(parent, style="Panel.TFrame")
        srow.pack(fill="x", pady=(4, 14))
        self.search_var = tk.StringVar()
        se = ttk.Entry(srow, textvariable=self.search_var)
        se.pack(side="left", fill="x", expand=True)
        se.bind("<Return>", lambda e: self.do_search())
        ttk.Button(srow, text="🔍", command=self.do_search).pack(side="left", padx=(6, 0))

        ttk.Separator(parent).pack(fill="x", pady=8)
        ttk.Label(parent, text="Percursos", style="H2.TLabel").pack(anchor="w")
        for label, kind in (("Pré-ordem", "pre"), ("Em-ordem", "in"),
                            ("Pós-ordem", "post"), ("BFS (em largura)", "bfs")):
            ttk.Button(parent, text=label, style="Ghost.TButton",
                       command=lambda k=kind: self.do_traversal(k)
                       ).pack(fill="x", pady=2)
        ttk.Button(parent, text="Limpar destaque", style="Ghost.TButton",
                   command=self.clear_traversal).pack(fill="x", pady=(2, 14))

        ttk.Separator(parent).pack(fill="x", pady=8)
        ttk.Label(parent, text="Manipulação local", style="H2.TLabel").pack(anchor="w")
        ttk.Label(parent, text="Selecione um nó na árvore para inserir/remover.",
                  style="Muted.TLabel", wraplength=240).pack(anchor="w", pady=(4, 6))
        ttk.Button(parent, text="➕ Inserir filho", command=self.do_insert
                   ).pack(fill="x", pady=2)
        ttk.Button(parent, text="🗑 Remover nó", style="Danger.TButton",
                   command=self.do_delete).pack(fill="x", pady=2)

    def _build_canvas(self, parent: ttk.Frame) -> None:
        wrapper = tk.Frame(parent, bg=PANEL)
        wrapper.pack(fill="both", expand=True)

        self.canvas = tk.Canvas(wrapper, bg=PANEL, highlightthickness=0)
        hbar = ttk.Scrollbar(wrapper, orient="horizontal", command=self.canvas.xview)
        vbar = ttk.Scrollbar(wrapper, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(xscrollcommand=hbar.set, yscrollcommand=vbar.set)

        self.canvas.grid(row=0, column=0, sticky="nsew")
        vbar.grid(row=0, column=1, sticky="ns")
        hbar.grid(row=1, column=0, sticky="ew")
        wrapper.rowconfigure(0, weight=1)
        wrapper.columnconfigure(0, weight=1)

        self.canvas.bind("<Button-1>", self._on_canvas_click)

    def _build_metrics(self, parent: ttk.Frame) -> None:
        ttk.Label(parent, text="Métricas", style="H2.TLabel").pack(anchor="w")
        self.metrics_text = tk.Text(parent, height=12, bg=BG, fg=TEXT,
                                    relief="flat", wrap="word",
                                    font=("Consolas", 10))
        self.metrics_text.pack(fill="x", pady=(8, 12))
        self.metrics_text.configure(state="disabled")

        ttk.Label(parent, text="Caminho (raiz → nó)", style="H2.TLabel").pack(anchor="w")
        self.path_text = tk.Text(parent, height=5, bg=BG, fg=TEXT,
                                 relief="flat", wrap="word", font=("Consolas", 10))
        self.path_text.pack(fill="x", pady=(8, 12))
        self.path_text.configure(state="disabled")

        ttk.Label(parent, text="Sequência do percurso", style="H2.TLabel").pack(anchor="w")
        self.trav_text = tk.Text(parent, height=10, bg=BG, fg=TEXT,
                                 relief="flat", wrap="word", font=("Consolas", 10))
        self.trav_text.pack(fill="both", expand=True, pady=(8, 0))
        self.trav_text.configure(state="disabled")

    # ---------- ações ----------
    def load_chain(self, name: str) -> None:
        name = (name or "").strip()
        if not name:
            return
        self.status.set(f"Carregando {name}…")

        def worker() -> None:
            try:
                tree = fetch_evolution_tree(name)
                self.after(0, lambda: self._on_loaded(tree, name))
            except Exception as e:
                self.after(0, lambda: messagebox.showerror("Erro", str(e)))
                self.after(0, lambda: self.status.set("Pronto."))

        threading.Thread(target=worker, daemon=True).start()

    def _on_loaded(self, tree: TreeNode, name: str) -> None:
        self.root_node = tree
        self.selected_id = tree.id
        self.found_id = None
        self.path_ids = {tree.id}
        self.traversal_label = ""
        self.traversal_names = []
        self._image_cache.clear()
        self.status.set(f"Cadeia de {name} carregada.")
        self.redraw()

    def do_search(self) -> None:
        if not self.root_node:
            return
        q = self.search_var.get()
        path = search_by_name(self.root_node, q)
        if not path:
            messagebox.showinfo("Busca", f'"{q}" não encontrado.')
            self.found_id = None
            return
        last = path[-1]
        self.found_id = last.id
        self.selected_id = last.id
        self.path_ids = {n.id for n in path}
        self.status.set(f'Encontrado em {len(path) - 1} nível(is).')
        self.redraw()

    def do_traversal(self, kind: str) -> None:
        if not self.root_node:
            return
        fns = {"pre": pre_order, "in": in_order, "post": post_order, "bfs": bfs}
        labels = {"pre": "Pré-ordem", "in": "Em-ordem",
                  "post": "Pós-ordem", "bfs": "BFS"}
        order = fns[kind](self.root_node)
        self.traversal_label = labels[kind]
        self.traversal_names = [n.name for n in order]
        self.redraw()

    def clear_traversal(self) -> None:
        self.traversal_label = ""
        self.traversal_names = []
        self.redraw()

    def do_insert(self) -> None:
        if not (self.root_node and self.selected_id):
            return
        parent = self._find(self.selected_id)
        if not parent:
            return
        name = simpledialog.askstring("Inserir filho",
                                      f'Nome do novo filho de "{parent.name}":',
                                      parent=self)
        if not name:
            return
        insert_child(parent, name.strip())
        self.status.set(f'Inserido "{name}" em "{parent.name}".')
        self.redraw()

    def do_delete(self) -> None:
        if not (self.root_node and self.selected_id):
            return
        if self.selected_id == self.root_node.id:
            messagebox.showwarning("Remover", "Não é possível remover a raiz.")
            return
        node = self._find(self.selected_id)
        if not node:
            return
        if not messagebox.askyesno("Remover",
                                   f'Remover "{node.name}" e toda a subárvore?'):
            return
        delete_node(self.root_node, self.selected_id)
        self.selected_id = self.root_node.id
        self.path_ids = {self.root_node.id}
        self.found_id = None
        self.status.set("Nó removido.")
        self.redraw()

    # ---------- helpers ----------
    def _find(self, node_id: str) -> Optional[TreeNode]:
        if not self.root_node:
            return None
        from tree import find_node
        return find_node(self.root_node, node_id)

    def _on_canvas_click(self, event: tk.Event) -> None:
        item = self.canvas.find_closest(self.canvas.canvasx(event.x),
                                        self.canvas.canvasy(event.y))
        if not item:
            return
        node_id = self._node_items.get(item[0])
        if not node_id and self.root_node:
            # tenta varrer todas as tags do item clicado
            for it in self.canvas.find_overlapping(
                    self.canvas.canvasx(event.x) - 2, self.canvas.canvasy(event.y) - 2,
                    self.canvas.canvasx(event.x) + 2, self.canvas.canvasy(event.y) + 2):
                if it in self._node_items:
                    node_id = self._node_items[it]
                    break
        if not node_id or not self.root_node:
            return
        self.selected_id = node_id
        path = find_path(self.root_node, node_id) or []
        self.path_ids = {n.id for n in path}
        self.redraw()

    # ---------- render ----------
    def redraw(self) -> None:
        self.canvas.delete("all")
        self._node_items.clear()
        if not self.root_node:
            self._update_side_panels()
            return

        positions, w, h = layout_tree(self.root_node)
        pad_x, pad_y = 40, 30
        self.canvas.configure(scrollregion=(0, 0, w + pad_x * 2, h + pad_y * 2))

        # arestas
        def draw_edges(n: TreeNode) -> None:
            x1, y1 = positions[n.id]
            for c in n.children:
                x2, y2 = positions[c.id]
                color = HIGHLIGHT if (n.id in self.path_ids and c.id in self.path_ids) else BORDER
                width = 3 if color == HIGHLIGHT else 2
                self.canvas.create_line(
                    x1 + pad_x, y1 + pad_y + NODE_H / 2,
                    x2 + pad_x, y2 + pad_y - NODE_H / 2,
                    fill=color, width=width, smooth=True,
                )
                draw_edges(c)
        draw_edges(self.root_node)

        # nós
        traversal_index = {nm: i for i, nm in enumerate(self.traversal_names)}

        def draw_node(n: TreeNode) -> None:
            cx, cy = positions[n.id]
            x, y = cx + pad_x, cy + pad_y
            x1, y1 = x - NODE_W / 2, y - NODE_H / 2
            x2, y2 = x + NODE_W / 2, y + NODE_H / 2

            if n.id == self.found_id:
                outline = SUCCESS; width = 3
            elif n.id == self.selected_id:
                outline = ACCENT; width = 3
            elif n.id in self.path_ids:
                outline = HIGHLIGHT; width = 2
            else:
                outline = BORDER; width = 1

            rect = self._round_rect(x1, y1, x2, y2, r=12, fill=BG, outline=outline, width=width)
            self._node_items[rect] = n.id

            # imagem (opcional, requer Pillow)
            text_x = x1 + 12
            if HAS_PIL and n.image_url:
                img = self._load_image(n.image_url)
                if img:
                    img_id = self.canvas.create_image(x1 + 28, y, image=img)
                    self._node_items[img_id] = n.id
                    text_x = x1 + 56

            label = self.canvas.create_text(text_x, y - 8, anchor="w",
                                            text=n.name.capitalize(),
                                            fill=TEXT, font=("Helvetica", 10, "bold"))
            self._node_items[label] = n.id

            sub = f"grau {len(n.children)}"
            if n.name in traversal_index:
                sub = f"#{traversal_index[n.name] + 1} · {sub}"
            sub_id = self.canvas.create_text(text_x, y + 10, anchor="w",
                                             text=sub, fill=MUTED,
                                             font=("Helvetica", 8))
            self._node_items[sub_id] = n.id

            for c in n.children:
                draw_node(c)

        draw_node(self.root_node)
        self._update_side_panels()

    def _round_rect(self, x1, y1, x2, y2, r=10, **kw) -> int:
        pts = [
            x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r,
            x2, y2 - r, x2, y2, x2 - r, y2, x1 + r, y2,
            x1, y2, x1, y2 - r, x1, y1 + r, x1, y1,
        ]
        return self.canvas.create_polygon(pts, smooth=True, **kw)

    def _load_image(self, url: str):
        if url in self._image_cache:
            return self._image_cache[url]
        try:
            with urllib.request.urlopen(url, timeout=10) as r:
                data = r.read()
            img = Image.open(io.BytesIO(data)).convert("RGBA")
            img.thumbnail((44, 44))
            ph = ImageTk.PhotoImage(img)
            self._image_cache[url] = ph
            return ph
        except Exception:
            return None

    def _update_side_panels(self) -> None:
        # métricas
        lines: List[str] = []
        if self.root_node:
            lines.append(f"Total de nós  : {count_nodes(self.root_node)}")
            lines.append(f"Altura árvore : {tree_height(self.root_node)}")
            sel = self._find(self.selected_id) if self.selected_id else None
            if sel:
                lines.append("")
                lines.append(f"Nó selecionado: {sel.name}")
                lines.append(f"  Grau (filhos): {node_degree(sel)}")
                lines.append(f"  Subárvore    : {count_nodes(sel)} nós")
                lines.append(f"  Altura local : {tree_height(sel)}")
        self._set_text(self.metrics_text, "\n".join(lines) or "—")

        # caminho
        if self.root_node and self.selected_id:
            path = find_path(self.root_node, self.selected_id) or []
            self._set_text(self.path_text, "  →  ".join(n.name for n in path) or "—")
        else:
            self._set_text(self.path_text, "—")

        # percurso
        if self.traversal_label:
            txt = f"{self.traversal_label}:\n  " + "  →  ".join(self.traversal_names)
        else:
            txt = "Nenhum percurso ativo."
        self._set_text(self.trav_text, txt)

    def _set_text(self, widget: tk.Text, content: str) -> None:
        widget.configure(state="normal")
        widget.delete("1.0", "end")
        widget.insert("1.0", content)
        widget.configure(state="disabled")


if __name__ == "__main__":
    EvoTreeApp().mainloop()
