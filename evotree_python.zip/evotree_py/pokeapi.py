"""Cliente da PokéAPI: baixa cadeia de evolução e converte para TreeNode."""
from __future__ import annotations
import json
import urllib.request
from typing import Any, Dict
from tree import TreeNode

BASE = "https://pokeapi.co/api/v2"


def _get(url: str) -> Dict[str, Any]:
    req = urllib.request.Request(url, headers={"User-Agent": "EvoTree/1.0"})
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read().decode("utf-8"))


def _species_id_from_url(url: str) -> str:
    # .../pokemon-species/133/
    parts = [p for p in url.split("/") if p]
    return parts[-1] if parts else ""


def _sprite_url(species_id: str) -> str:
    return (
        "https://raw.githubusercontent.com/PokeAPI/sprites/master/"
        f"sprites/pokemon/other/official-artwork/{species_id}.png"
    )


def _chain_to_tree(chain: Dict[str, Any]) -> TreeNode:
    sid = _species_id_from_url(chain["species"]["url"])
    node = TreeNode(
        name=chain["species"]["name"].capitalize(),
        image_url=_sprite_url(sid) if sid else None,
    )
    for evo in chain.get("evolves_to", []):
        node.add_child(_chain_to_tree(evo))
    return node


def fetch_evolution_tree(species_name: str) -> TreeNode:
    species = _get(f"{BASE}/pokemon-species/{species_name.lower().strip()}")
    chain = _get(species["evolution_chain"]["url"])
    return _chain_to_tree(chain["chain"])
