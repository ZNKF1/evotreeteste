"""Estrutura de Árvore N-ária + algoritmos clássicos.

Implementa:
  - Nó (TreeNode) com referências (ponteiros) aos filhos
  - Percursos: pré-ordem, em-ordem, pós-ordem, BFS
  - Busca por nome (BFS) com caminho da raiz até o nó
  - Inserção e remoção mantendo a integridade da hierarquia
  - Métricas: altura da árvore, grau do nó, contagem de nós
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional, Callable
import itertools

_id_counter = itertools.count(1)

def gen_id() -> str:
    return f"n{next(_id_counter)}"


@dataclass
class TreeNode:
    name: str
    image_url: Optional[str] = None
    children: List["TreeNode"] = field(default_factory=list)
    id: str = field(default_factory=gen_id)
    parent: Optional["TreeNode"] = field(default=None, repr=False, compare=False)

    # ---------- manipulação ----------
    def add_child(self, child: "TreeNode") -> None:
        child.parent = self
        self.children.append(child)

    def remove_child(self, child: "TreeNode") -> bool:
        if child in self.children:
            self.children.remove(child)
            child.parent = None
            return True
        return False


# ---------- buscas ----------
def find_node(root: TreeNode, node_id: str) -> Optional[TreeNode]:
    if root.id == node_id:
        return root
    for c in root.children:
        f = find_node(c, node_id)
        if f:
            return f
    return None


def find_path(root: TreeNode, node_id: str) -> Optional[List[TreeNode]]:
    """Caminho da raiz até o nó alvo (DFS)."""
    def go(n: TreeNode, acc: List[TreeNode]) -> Optional[List[TreeNode]]:
        acc = acc + [n]
        if n.id == node_id:
            return acc
        for c in n.children:
            r = go(c, acc)
            if r:
                return r
        return None
    return go(root, [])


def search_by_name(root: TreeNode, query: str) -> Optional[List[TreeNode]]:
    """BFS: retorna o caminho até o primeiro nó cujo nome contém `query`."""
    q = query.strip().lower()
    if not q:
        return None
    queue: list[tuple[TreeNode, list[TreeNode]]] = [(root, [root])]
    while queue:
        node, path = queue.pop(0)
        if q in node.name.lower():
            return path
        for c in node.children:
            queue.append((c, path + [c]))
    return None


# ---------- modificação (mantém ponteiros íntegros) ----------
def insert_child(parent: TreeNode, name: str, image_url: Optional[str] = None) -> TreeNode:
    new_node = TreeNode(name=name, image_url=image_url)
    parent.add_child(new_node)
    return new_node


def delete_node(root: TreeNode, node_id: str) -> bool:
    """Remove o nó e toda a sua subárvore. Não permite remover a raiz."""
    if root.id == node_id:
        return False
    target = find_node(root, node_id)
    if target is None or target.parent is None:
        return False
    return target.parent.remove_child(target)


# ---------- métricas ----------
def tree_height(node: TreeNode) -> int:
    if not node.children:
        return 0
    return 1 + max(tree_height(c) for c in node.children)


def node_degree(node: TreeNode) -> int:
    return len(node.children)


def count_nodes(node: TreeNode) -> int:
    return 1 + sum(count_nodes(c) for c in node.children)


# ---------- percursos ----------
def pre_order(node: TreeNode) -> List[TreeNode]:
    out = [node]
    for c in node.children:
        out.extend(pre_order(c))
    return out


def post_order(node: TreeNode) -> List[TreeNode]:
    out: List[TreeNode] = []
    for c in node.children:
        out.extend(post_order(c))
    out.append(node)
    return out


def in_order(node: TreeNode) -> List[TreeNode]:
    """Em-ordem generalizado: 1º filho -> raiz -> demais filhos."""
    if not node.children:
        return [node]
    first, *rest = node.children
    out = in_order(first) + [node]
    for c in rest:
        out.extend(in_order(c))
    return out


def bfs(node: TreeNode) -> List[TreeNode]:
    out: List[TreeNode] = []
    queue = [node]
    while queue:
        n = queue.pop(0)
        out.append(n)
        queue.extend(n.children)
    return out
